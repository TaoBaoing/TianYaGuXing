﻿namespace 物业任务发布平台
{
    partial class TaskBillEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtYeZhuName = new System.Windows.Forms.TextBox();
            this.txtCreateTime = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBillState = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtTName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtYeWuYuanName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFinishDateTime = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lblPingJia = new System.Windows.Forms.Label();
            this.txtPingJia = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(104, 56);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(365, 128);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "服务说明";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "服务名称";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(69, 202);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "业主";
            // 
            // txtYeZhuName
            // 
            this.txtYeZhuName.Location = new System.Drawing.Point(104, 199);
            this.txtYeZhuName.Name = "txtYeZhuName";
            this.txtYeZhuName.Size = new System.Drawing.Size(141, 21);
            this.txtYeZhuName.TabIndex = 8;
            // 
            // txtCreateTime
            // 
            this.txtCreateTime.Location = new System.Drawing.Point(328, 199);
            this.txtCreateTime.Name = "txtCreateTime";
            this.txtCreateTime.Size = new System.Drawing.Size(141, 21);
            this.txtCreateTime.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(269, 202);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "创建时间";
            // 
            // txtBillState
            // 
            this.txtBillState.Location = new System.Drawing.Point(104, 237);
            this.txtBillState.Name = "txtBillState";
            this.txtBillState.Size = new System.Drawing.Size(365, 21);
            this.txtBillState.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(69, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 11;
            this.label5.Text = "状态";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(147, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 36);
            this.button1.TabIndex = 13;
            this.button1.Text = "设置任务完成";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtTName
            // 
            this.txtTName.Location = new System.Drawing.Point(104, 12);
            this.txtTName.Name = "txtTName";
            this.txtTName.Size = new System.Drawing.Size(365, 21);
            this.txtTName.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 11;
            this.label6.Text = "业务员";
            // 
            // txtYeWuYuanName
            // 
            this.txtYeWuYuanName.Location = new System.Drawing.Point(104, 281);
            this.txtYeWuYuanName.Name = "txtYeWuYuanName";
            this.txtYeWuYuanName.Size = new System.Drawing.Size(141, 21);
            this.txtYeWuYuanName.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(269, 284);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 11;
            this.label7.Text = "完成时间";
            // 
            // txtFinishDateTime
            // 
            this.txtFinishDateTime.Location = new System.Drawing.Point(328, 281);
            this.txtFinishDateTime.Name = "txtFinishDateTime";
            this.txtFinishDateTime.Size = new System.Drawing.Size(141, 21);
            this.txtFinishDateTime.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(294, 402);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 36);
            this.button2.TabIndex = 15;
            this.button2.Text = "关  闭";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lblPingJia
            // 
            this.lblPingJia.AutoSize = true;
            this.lblPingJia.Location = new System.Drawing.Point(45, 326);
            this.lblPingJia.Name = "lblPingJia";
            this.lblPingJia.Size = new System.Drawing.Size(53, 12);
            this.lblPingJia.TabIndex = 11;
            this.lblPingJia.Text = "业主评价";
            // 
            // txtPingJia
            // 
            this.txtPingJia.Location = new System.Drawing.Point(104, 323);
            this.txtPingJia.Name = "txtPingJia";
            this.txtPingJia.Size = new System.Drawing.Size(365, 63);
            this.txtPingJia.TabIndex = 6;
            this.txtPingJia.Text = "";
            // 
            // TaskBillEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 460);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.txtTName);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtFinishDateTime);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtYeWuYuanName);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtBillState);
            this.Controls.Add(this.lblPingJia);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtCreateTime);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtYeZhuName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtPingJia);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TaskBillEdit";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "服务详情";
            this.Load += new System.EventHandler(this.TaskBillEdit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtYeZhuName;
        private System.Windows.Forms.TextBox txtCreateTime;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBillState;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtTName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtYeWuYuanName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFinishDateTime;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblPingJia;
        private System.Windows.Forms.RichTextBox txtPingJia;
    }
}