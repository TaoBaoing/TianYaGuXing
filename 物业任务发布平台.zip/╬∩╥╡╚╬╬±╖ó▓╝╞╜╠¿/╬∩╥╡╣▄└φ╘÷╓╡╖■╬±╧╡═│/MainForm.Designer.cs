﻿namespace 物业任务发布平台
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.用户管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.服务任务管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.选择服务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询服务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.业务员领取任务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.业主评价服务ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统ToolStripMenuItem,
            this.用户管理ToolStripMenuItem,
            this.服务任务管理ToolStripMenuItem,
            this.选择服务ToolStripMenuItem,
            this.查询服务ToolStripMenuItem,
            this.业务员领取任务ToolStripMenuItem,
            this.业主评价服务ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(622, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 系统ToolStripMenuItem
            // 
            this.系统ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.退出ToolStripMenuItem});
            this.系统ToolStripMenuItem.Name = "系统ToolStripMenuItem";
            this.系统ToolStripMenuItem.Size = new System.Drawing.Size(44, 21);
            this.系统ToolStripMenuItem.Text = "系统";
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            this.退出ToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.退出ToolStripMenuItem.Text = "退出";
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // 用户管理ToolStripMenuItem
            // 
            this.用户管理ToolStripMenuItem.Enabled = false;
            this.用户管理ToolStripMenuItem.Name = "用户管理ToolStripMenuItem";
            this.用户管理ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.用户管理ToolStripMenuItem.Text = "用户管理";
            this.用户管理ToolStripMenuItem.Click += new System.EventHandler(this.用户管理ToolStripMenuItem_Click);
            // 
            // 服务任务管理ToolStripMenuItem
            // 
            this.服务任务管理ToolStripMenuItem.Enabled = false;
            this.服务任务管理ToolStripMenuItem.Name = "服务任务管理ToolStripMenuItem";
            this.服务任务管理ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.服务任务管理ToolStripMenuItem.Text = "服务任务管理";
            this.服务任务管理ToolStripMenuItem.Click += new System.EventHandler(this.服务任务管理ToolStripMenuItem_Click);
            // 
            // 选择服务ToolStripMenuItem
            // 
            this.选择服务ToolStripMenuItem.Enabled = false;
            this.选择服务ToolStripMenuItem.Name = "选择服务ToolStripMenuItem";
            this.选择服务ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.选择服务ToolStripMenuItem.Text = "业主选择服务";
            this.选择服务ToolStripMenuItem.Click += new System.EventHandler(this.选择服务ToolStripMenuItem_Click);
            // 
            // 查询服务ToolStripMenuItem
            // 
            this.查询服务ToolStripMenuItem.Name = "查询服务ToolStripMenuItem";
            this.查询服务ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.查询服务ToolStripMenuItem.Text = "查询服务";
            this.查询服务ToolStripMenuItem.Click += new System.EventHandler(this.查询服务ToolStripMenuItem_Click);
            // 
            // 业务员领取任务ToolStripMenuItem
            // 
            this.业务员领取任务ToolStripMenuItem.Enabled = false;
            this.业务员领取任务ToolStripMenuItem.Name = "业务员领取任务ToolStripMenuItem";
            this.业务员领取任务ToolStripMenuItem.Size = new System.Drawing.Size(104, 21);
            this.业务员领取任务ToolStripMenuItem.Text = "业务员领取任务";
            this.业务员领取任务ToolStripMenuItem.Click += new System.EventHandler(this.业务员领取任务ToolStripMenuItem_Click);
            // 
            // 业主评价服务ToolStripMenuItem
            // 
            this.业主评价服务ToolStripMenuItem.Enabled = false;
            this.业主评价服务ToolStripMenuItem.Name = "业主评价服务ToolStripMenuItem";
            this.业主评价服务ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
            this.业主评价服务ToolStripMenuItem.Text = "业主评价服务";
            this.业主评价服务ToolStripMenuItem.Click += new System.EventHandler(this.业主评价服务ToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Enabled = false;
            this.button1.Location = new System.Drawing.Point(94, 54);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "用  户  管  理";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(342, 54);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(164, 42);
            this.button2.TabIndex = 1;
            this.button2.Text = "服 务 任 务 管 理";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Enabled = false;
            this.button3.Location = new System.Drawing.Point(94, 139);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(164, 42);
            this.button3.TabIndex = 1;
            this.button3.Text = "查  询  服  务";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Enabled = false;
            this.button4.Location = new System.Drawing.Point(342, 139);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(164, 42);
            this.button4.TabIndex = 1;
            this.button4.Text = "业 主 选 择 服 务";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Enabled = false;
            this.button5.Location = new System.Drawing.Point(94, 230);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(164, 42);
            this.button5.TabIndex = 1;
            this.button5.Text = "业 务 员 领 取 任 务";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Enabled = false;
            this.button6.Location = new System.Drawing.Point(342, 230);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(164, 42);
            this.button6.TabIndex = 1;
            this.button6.Text = "业 主 评 价 服 务";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "本程序由 殇 开发完成";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(94, 316);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(164, 42);
            this.button7.TabIndex = 1;
            this.button7.Text = "退        出";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 396);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "物业管理增值服务系统";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 用户管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 服务任务管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 选择服务ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询服务ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 业务员领取任务ToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ToolStripMenuItem 业主评价服务ToolStripMenuItem;
    }
}