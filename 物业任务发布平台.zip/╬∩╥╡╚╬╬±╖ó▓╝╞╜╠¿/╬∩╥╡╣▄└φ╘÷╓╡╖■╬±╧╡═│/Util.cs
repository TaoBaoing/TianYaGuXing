﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace 物业任务发布平台
{
    public class Util
    {
        public static MUser User { get; set; }
    }
}
